import { Calculadora } from "./Calculadora.js";

customElements.define('calculadora-basica', Calculadora);
